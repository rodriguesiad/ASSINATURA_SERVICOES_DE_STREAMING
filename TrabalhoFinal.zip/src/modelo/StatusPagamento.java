package modelo;

public enum StatusPagamento {
	PENDENTE, PAGO;
}
