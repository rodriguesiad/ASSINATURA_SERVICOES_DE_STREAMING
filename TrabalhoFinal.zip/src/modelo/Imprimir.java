package modelo;

public interface Imprimir {

	public void imprimir();

}
