package modelo.usuario;

public class Funcionario extends Usuario {

	public Funcionario(String email, String senha) {
		super(email, senha);
		// TODO Auto-generated constructor stub
	}

}
